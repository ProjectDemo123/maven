#define _FORTIFY_SOURCE 2
#include "tst-chk1.c"
