extern int bar (void);

int
bar (void)
{
  return 42;
}
