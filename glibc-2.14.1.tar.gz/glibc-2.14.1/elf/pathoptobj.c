extern int in_renamed (int);


int
in_renamed (int a)
{
  return a - 10;
}
